package com.courier.model;

public enum UserRole {
    CUSTOMER,
    OFFICER
} 