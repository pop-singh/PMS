export interface CancelResponse {
  success: boolean;
  message: string;
} 